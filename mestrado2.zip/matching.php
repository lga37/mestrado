<?php
echo "<pre>";
$cn = new PDO("mysql:host=localhost;dbname=mestrado","root","");

#$results = $cn->query("select * from puc where (match is null or match=0) order by id;");
$results = $cn->query("select * from puc order by id;");
$pucs = $results->fetchAll(PDO::FETCH_ASSOC);
print_r($pucs);

foreach($pucs as $puc){
	$puc_id = $puc['id'];
	$nome_puc = $puc['nome'];
	$nascimento = $puc['nascimento'];
	$curso = $puc['curso'];
		
	#$q = "select * from alumni where nome like %".$nome_puc."% and match is null or match=0 ";
	$q = "select * from alumni where nome like '%".$nome_puc."%' ";
	#if($nascimento){
	#	$q .= "and aniversario=".$nascimento;
	#}
	$q .= "order by id;";
	echo $q;
	$results = $cn->query($q);
	$matchings = $results->fetchAll(PDO::FETCH_ASSOC);
	echo "<hr>Para $nome_puc :.<br>";
	print_r($matchings);

}
